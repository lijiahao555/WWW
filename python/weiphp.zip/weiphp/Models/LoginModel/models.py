from django.db import models
# models.py
class Login(models.Model):
    username = models.CharField(max_length=40)
    password = models.IntegerField(max_length=32)