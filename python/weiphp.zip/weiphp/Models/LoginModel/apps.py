from django.apps import AppConfig


class LoginmodelConfig(AppConfig):
    name = 'LoginModel'
