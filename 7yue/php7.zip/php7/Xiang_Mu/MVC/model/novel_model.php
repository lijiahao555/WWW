<?php


class novel_model extends model{

	public $table_name = 'novel';

}