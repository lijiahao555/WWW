<?php

return array(

		'dbname'             =>'1511phpa',
		'host'               =>'127.0.0.1',
		'dbuser'             =>'root',
		'dbpwd'              =>'root',
		'dbtype'             =>'mysql',
		'prefix'             =>'',
		'charset'            =>'utf8',
		
		'default_controller' =>'welcome',
		'default_action'     =>'index',
		
		//模板布局
		'layout_on'          =>true,//false,true
		'layout_html'        =>'layout'
	);