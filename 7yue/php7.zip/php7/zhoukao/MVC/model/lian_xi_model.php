<?php


class lian_xi_model extends model{

	public $table_name = 'lian_xi';// 数据库,表名称

	public function show(){

		echo 'aabb';
	}

}