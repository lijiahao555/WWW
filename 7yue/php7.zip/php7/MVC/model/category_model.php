<?php


class category_model extends model{

	public $table_name = 'category';

	public function show(){

		echo 'aabb';
	}

}