<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<img src="one.png" width="300px" alt="">
	<a href="cuo.zip">下载</a>
</body>
</html>