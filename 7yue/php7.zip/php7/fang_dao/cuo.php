<?php 
echo "盗图小屁孩";
 ?>