<?php


class Lian_xi_model extends model{

	public $table_name = 'lian_xi';

}