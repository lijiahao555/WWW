<?php

class bookss_model extends model{

	public $table_name = 'bookss';

}