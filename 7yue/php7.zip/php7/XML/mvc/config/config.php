<?php
//配置文件
return array(

		'dbname'	=>'text',
		'host'		=>'127.0.0.1',
		'dbuser'	=>'root',
		'dbpwd'		=>'root',
		'dbtype'	=>'mysql',
		'prefix'	=>'',
		'charset'	=>'utf8',

		'default_controller'=>'welcome',
		'default_action'	=>'index',

		//模板布局
		'layout_on'			=>false,
		'layout_html'		=>'layout'
	);