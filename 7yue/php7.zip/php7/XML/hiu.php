<?php
/**
 * @Author: Marte
 * @Date:   2017-10-14 09:15:03
 * @Last Modified by:   Marte
 * @Last Modified time: 2017-10-14 09:17:48
 */
setcookie('a','b');
echo $_COOKIE['a'];