<?php


class admin_model extends model{

	public $table_name = 'test_error';

	public function show(){
	
		echo 'aabb';		
	}

}