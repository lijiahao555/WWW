<?php

return array(

		'dbname'=>'test',
		'host'=>'localhost',
		'dbuser'=>'root',
		'dbpwd'=>'root',
		'dbtype'=>'mysql',
		'prefix'=>'',
		'charset'=>'utf8',

		'default_controller'=>'welcome',
		'default_action'=>'index',

		//模板布局
		'layout_on'=>true,
		'layout_html'=>'layout'
	);