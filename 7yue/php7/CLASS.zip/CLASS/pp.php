<?php 
header("content-type:text/html;charset=utf-8");

var_dump($_GET);
var_dump($_POST);
// echo "666";

 ?>